from setuptools import setup
setup(name='prerng',
      version='0.1',
      description='in-lab time-locking of study preregistration',
      url='https://github.com/matanmazor/preRNG/tree/master/Python/prerng',
      author='Mazor Bros',
      author_email='matanmazor@outlook.com',
      license='3 clause bsd',
      packages=['preRNG'],
      zip_safe=False)
